%% Pick up and put the 'yCan1' in the green bin
goHome;
moveAboveCan(-0.165, 0.703, 0.13, -pi/2, -pi, 0);
pause(5);
closeOnCan;
pause(3);
Move_to_Green_bin;
pause(3);
openClaw;
pause(3);
host_name = '192.168.56.128';
rosshutdown;
rosinit(host_name);
goHome;

%% Pick up and put the 'yCan2' in the green bin

moveAboveCan(0.482, 0.65, 0.3, pi/3.5, -pi, 0);
pause(3);
moveAboveCan(0.482, 0.65, 0.1, pi/3.5, -pi, 0);
pause(5);
closeOnCan;
pause(3);
moveAboveCan(0.482, 0.65, 0.3, -pi/2, -pi, 0);
pause(3);
Move_to_Green_bin;
pause(5);
openClaw;
pause(3);
host_name = '192.168.56.128';
rosshutdown;
rosinit(host_name);
pause(3);
goHome;

%% Pick up and put the 'yCan3' in the green bin

moveAboveCan(0.45, 0.46, 0.3, -pi/2, -pi, 0);
pause(3);
moveAboveCan(0.448, 0.461, 0.143, -pi/4, -pi, 0); % can is falling, values need to be tweaked
pause(5);
closeOnCan;
pause(3);
moveAboveCan(0.45, 0.46, 0.3, -pi/2, -pi, 0);
pause(3);
Move_to_Green_bin;
pause(5);
openClaw;
pause(3);
host_name = '192.168.56.128';
rosshutdown;
rosinit(host_name);
goHome;
